<?php
$page = $_SERVER['PHP_SELF'];
$sec = "60";
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="<?php echo $sec?>;URL='<?php echo $page?>'">
    </head>
<body>
	<?php
$row = 1;
if (($handle = fopen("/var/log/mhn/mhn-json.log", "r")) !== FALSE) {
  while (($data = fgetcsv($handle)) !== FALSE) {
    $num = count($data);
   
    $row++;
    for ($c=0; $c < $num; $c++) {
		$ip=$data[$c];
        echo "<div>src_ip:" . $data[$c] . "</div> ";
	
$access_key = 'e91648d33f7927a3e32ad24a8eb33389';

// Initialize CURL:
$ch = curl_init('http://api.ipstack.com/'.$ip.'?access_key='.$access_key.'');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

// Store the data:
$json = curl_exec($ch);
curl_close($ch);

// Decode JSON response:
$api_result = json_decode($json, true);

// Output the "capital" object inside "location"
echo " <div>latitude:" . $api_result['latitude'] . "</div>";
echo "<div>Longitude:" . $api_result['longitude'] . "</div> ";
echo " <div>latitude:" . $api_result['country_name'] . "</div>  <br />\n";
$lat=$api_result['latitude'];
$lon=$api_result['longitude'];
$con=$api_result['country_name'];


$fp = fopen("srlatlong3.csv", 'a');  //Open file for append
//fwrite($fp, $row1.",".$row2); //Append row,row to file
fputcsv($fp, array($lon, $lat ,$con, $ip)); //@Optimist
fclose($fp); //Close the file to free memory.

    }
  }
  fclose($handle);
}

?>
  



</body>
</html>

